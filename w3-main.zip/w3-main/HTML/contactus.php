<!DOCTYPE html>
<head>
    <title>w3-Study: Study online with others for free</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Study online collaboratively with w3-Study">
    <link rel="icon" href="https://lh3.googleusercontent.com/Ds7Q0Br23zo_VCLVkmkx4LOK692sTRZaGP6hPL1e2g85EiWRn0XlEHMpZtE5mCWk9zVMCL-Y1dZN118HLn6QbQ9_TkV_mbWJSDUf2DRoixvj3rCI_lVxCDDcqHznZoNyRERVtyLTPw=w2400">
</head>
<body>
    <link href="/css/websitecss.css" rel="stylesheet" type = "text/css">
	<header class = "header"> Contact Us </header>
	<hr>
	<p class = "p"> Email: <a href = mailto:"w3study.contact@gmail.com" style = "color: cyan"> w3study.contact@gmail.com </a></p>
	<p class = "p"> Facebook: <a href="https://www.facebook.com/W3-study-104382282199706" style = "color: cyan" target="_blank"> @W3-study</a></p>
	<p class = "p"> Instagram: <a href = "https://www.instagram.com/w3_study/" style = "color: cyan" target="_blank"> @w3_study </a></p>
	<button id = "back" onclick = "back()"> Back </button>
	<script src = "/js/websitejs.js"></script>
</body>
</html>