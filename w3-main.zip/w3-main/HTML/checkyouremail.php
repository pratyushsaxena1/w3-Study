<!DOCTYPE html>
<head>
    <title>w3-Study: Study online with others for free</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Study online collaboratively with w3-Study">
    <link rel="icon" href="https://lh3.googleusercontent.com/Ds7Q0Br23zo_VCLVkmkx4LOK692sTRZaGP6hPL1e2g85EiWRn0XlEHMpZtE5mCWk9zVMCL-Y1dZN118HLn6QbQ9_TkV_mbWJSDUf2DRoixvj3rCI_lVxCDDcqHznZoNyRERVtyLTPw=w2400">
</head>
<body>
    <link href="/css/websitecss.css" rel="stylesheet" type = "text/css">
	<header class = "header"> Email Verification </header>
    <hr>
	<p>Check your <a href = "https://webmail.tjhsst.edu/" target = _blank style = "color: cyan">Webmail</a> to create your account. It make take a few minutes for the email to go through. <br> Please leave this tab open until you verify your email.</p>
	<button id = "back" onclick = "back()"> Back </button>
	<script src = "/js/websitejs.js"></script>
</body>
</html>